package io.github.aedev.flow.data.music.artwork

import io.github.aedev.flow.data.music.model.MusicTrack
import io.github.aedev.flow.data.music.model.musicArtistKey
import io.github.aedev.flow.data.music.model.musicBaseTitle
import io.github.aedev.flow.data.music.model.musicTitleKey
import kotlinx.serialization.Serializable

/** What the artwork service answers: the matched song and, when its album has one, the loop. */
@Serializable
internal data class ArtworkAnswer(
    val name: String? = null,
    val artist: String? = null,
    val animated: String? = null,
)

/**
 * How a song is asked for and how an answer is trusted. A loop belongs to an album, so the songs
 * of one album share a single lookup, and an answer counts only when it names the same song by the
 * same artist: a near miss would put another record's artwork on this one.
 */
internal object AnimatedArtworkLookup {
    data class Query(
        val title: String,
        val artist: String,
    )

    fun artist(track: MusicTrack): String = track.artists.firstOrNull()?.name ?: track.artist

    /** The song as titled, then without brackets or featured artists, each asked for once. */
    fun queries(track: MusicTrack): List<Query> {
        val artist = artist(track).removeSuffix(TOPIC_SUFFIX).trim()
        return listOf(track.title, musicBaseTitle(track.title))
            .filter(String::isNotBlank)
            .distinct()
            .map { Query(it, artist) }
    }

    fun key(track: MusicTrack): String {
        val release = track.album.takeIf(String::isNotBlank) ?: track.title
        return "${musicArtistKey(artist(track))}|${musicTitleKey(release)}"
    }

    fun accepts(
        track: MusicTrack,
        answer: ArtworkAnswer,
    ): Boolean {
        val name = answer.name ?: return false
        val artist = answer.artist ?: return false
        val artists = track.artists.map { it.name }.ifEmpty { listOf(track.artist) }
        return musicTitleKey(name, artists) == musicTitleKey(track.title, artists) &&
            musicArtistKey(artist).contains(musicArtistKey(artist(track)))
    }

    private const val TOPIC_SUFFIX = " - Topic"
}
